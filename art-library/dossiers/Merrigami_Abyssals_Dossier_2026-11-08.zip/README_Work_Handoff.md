# Merrigami — Abyssals dossier package (2026-11-08)

Single-stage Normal/Ghost special attacker, approved illustration, proposed growth and complete 1–63 learnset.

## Contents
- `Merrigami_Work_Dossier.docx` — editable species, balance, ability, learnset, spawn and bespoke Phantom Falchion animation spec.
- `Merrigami_approved_concept.png` — UNMODIFIED approved artwork; use as visual authority.
- `Merrigami_battle.png` — transparent cutout from approved artwork for reference/layout; NOT yet a final pixel-art battle sprite. Please recreate in the exact current Abyssals pixel style before game integration.

## Hard requirements
- Name: **Merrigami**, not Meergami.
- Signature move **Phantom Falchion at level 33**.
- Move is **Ghost / Special**, base power 70 + 10 per positive stat stage, then clears ALL positive stages after attack.
- Exclusive ability **Ancestral Aid**, +1 Sp. Atk on each successful special attack, maximum 3 stages granted by ability per uninterrupted appearance; other boosts can go to +6.
- `Focus Lance` (move 465) is a pre-existing Fighting / Special 80-power NEVER-MISS move, learned here at level 25.
- Maintain the standard repository tests and creative guidelines in `AGENTS.md`. No changes are committed to the repo in this pack.
