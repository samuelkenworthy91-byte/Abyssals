# Abyssals — Implementation Master

Status: **AUTHORITATIVE ENGINEERING CONTRACT v0.1**

## Core rule

**Implement the locked design. Do not redesign it.**

A coding agent may choose reversible engineering details, but it may not invent mechanics, silently tune locked values, simplify locked state machines, create alternate canon, infer mechanics from UI animation order, introduce reload rerolls, or use legacy `Pokemon` terminology in new player-facing content.

When a fact is missing or contradictory, record it and gate only the affected feature.

## Source precedence

Use `docs/engineering/SOURCE_AUTHORITY.md`. In short:

1. latest explicit user-approved instruction/revision;
2. latest version of the owning locked checklist;
3. other locked checklists within delegated authority;
4. locked Story Bible for narrative;
5. designated canonical workbooks/references;
6. engineering ADRs/phase specs;
7. code/tests.

Code never overrules canon.

## Non-negotiable implementation qualities

- deterministic RNG where canon requires it;
- stable IDs separate from display labels;
- Ironman-safe irreversible transactions;
- schema-versioned persistence;
- domain logic separated from presentation;
- validated content imports rather than catalogue copy/paste;
- mobile-readable UI and non-colour-only accessibility;
- regression tests for locked edge cases.

## Architecture boundaries

- `core`: IDs, deterministic primitives, RNG, math.
- `domain`: canonical presentation-independent models.
- `battle`: state machine/resolution.
- `capture`: legality/chance/result.
- `progression`: XP, growth, moves, evolution.
- `roster`: party, reserve, death, memorial, resurrection.
- `save`: snapshots, journal, migrations, integrity, single writer.
- `story`: authoritative state/event transactions.
- `overworld`: maps, collision, interaction, encounter triggering.
- `ui`: presentation only; never owns mechanics.
- `data`: generated/validated content artifacts.

## Data policy

Canonical spreadsheets and locked documents are source inputs, not runtime databases. Importers must normalize, validate, emit deterministic runtime data and retain source-row provenance. Never manually maintain a second competing 187-species or 354-move catalogue.

## Save policy

Production irreversible gameplay must honour Checklist 15. Temporary developer saves may exist only in isolated sandboxes and must not be mistaken for production Ironman behaviour.

## Art policy

The existing 187 front-facing species sprites are sufficient for ordinary canonical battle presentation. No mandatory back-sprite pipeline may be introduced. Human full-body portraits will later serve dialogue and trainer/leader introduction roles. Environment assets use stable IDs so art can be replaced without rewriting game logic.

## Definition of done

A task is complete only when code, applicable tests, data validation, canon-safety checks, changelog updates and blocker reporting are complete.

## Production sequence

Repository/source authority → Phase 0 → Phase 1 → physical test gate → close overworld/content gaps → Phase 2 → chapter expansion.
