# Abyssals

Production repository bootstrap for **Abyssals**, a monster-capture RPG with deterministic progression, permanent death, Ironman persistence, and a story-driven mortal-world / underworld campaign.

## Current state

This repository is at **engineering bootstrap** stage.

- Locked pre-production sources are governed by `docs/locked/SOURCE_MANIFEST.md`.
- The 187 canonical front-facing Abyssal sprites already exist but are not bundled in this bootstrap.
- Human full-body portraits and environment art will be added later through stable asset manifests.
- Phase 0 and Phase 1 can begin before final environment art exists.
- Production overworld work is gated by the missing completed Checklist 17 lock and unpopulated species-by-species encounter tables. See `docs/engineering/KNOWN_GAPS.md`.

## Read first

1. `IMPLEMENTATION_MASTER.md`
2. `docs/engineering/SOURCE_AUTHORITY.md`
3. `AGENTS.md` or `CLAUDE.md`
4. `docs/engineering/KNOWN_GAPS.md`
5. the active phase specification

## Proposed engineering baseline

TypeScript + Vite + Vitest are used as an engine-neutral development shell. No renderer/game engine is locked. See `docs/engineering/ADR-0001-runtime-stack.md`.

```bash
npm install
npm run validate
npm run dev
```

## Phase gates

- **Phase 0 — Systems Bootstrap**
- **Phase 1 — Battle Sandbox**
- **Phase 2 — Vertical Slice** only after Phase 0/1 pass and overworld/content gaps close.

Legacy source filenames may contain `Pokemon`; new player-facing terminology is **Abyssal / Abyssals**.
