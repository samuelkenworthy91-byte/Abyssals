# Locked Source Manifest

Copy original locked files here **unchanged**. Do not replace originals with summaries.

## Planning / narrative/reference
- `Pokemon_Pre_Programming_Planning_Checklists_Reference.docx`
- `Pokemon_Story_Bible_Full_Plot_LOCKED_v1.0.docx`
- `CHECKLIST_02_03_LOCKED_REFERENCE_v1.1.md`
- `WORLD_TOWNS_ROUTES_REFERENCE_v1.1.md`
- `ENCOUNTER_TABLE_REFERENCE_v1.1.md`

## Located locked checklist outputs
- Checklist 04 v1.0
- Checklist 05 v1.0
- Checklist 06 v1.0
- Checklist 07 v1.0
- Checklist 08 v1.0
- Checklist 09 **v1.1**
- Checklist 10 v1.0
- Checklist 11 v1.0
- Checklist 12 v1.0
- Checklist 13 v1.0
- Checklist 14 v1.0
- Checklist 15 v1.0
- Checklist 16 v1.0

Checklist 01 mechanics are present in the validated growth workbook and cited by later locks, but a standalone Checklist 01 locked artifact has not yet been imported. Checklist 17's scope exists in the master reference, but a completed locked artifact has not been located.

## Canonical bulk data
Place in `data/source/`:
- `Pokemon_Fan_Game_354_Move_Catalogue.xlsx`
- `Regional_Dex_Progression_Learnsets_v3.xlsx`
- `Regional_Dex_Stats_and_Abilities_COMPLETE_v2.xlsx`
- `Regional_Dex_Growth_and_Evolution_VALIDATED_v4.xlsx`

Runtime/generated data must be reproducible from these sources plus owning locked overlays.
