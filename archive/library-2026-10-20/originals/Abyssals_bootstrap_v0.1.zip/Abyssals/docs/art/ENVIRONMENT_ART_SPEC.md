# Environment Art Integration Spec

Environment art is a separate production workstream.

Expected reusable families include route/open country, woodland/scrub, cave/tunnel, ruin/archive, settlement exterior, interior/dungeon, battlefield/war zone and Hell.

World logic must not depend on finished art. Collision/navigation/world state use explicit map data/stable IDs, allowing art replacement without rewriting story or battle rules.
