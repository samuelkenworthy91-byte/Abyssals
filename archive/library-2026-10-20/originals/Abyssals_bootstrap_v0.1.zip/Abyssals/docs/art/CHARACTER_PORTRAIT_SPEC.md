# Character Portrait Integration Spec

Status: **ASSET HANDOFF CONTRACT**

One approved full-body human portrait can serve dialogue, trainer introduction, leader introduction and suitable pre-send-out/story battle beats. Separate variants are optional only when presentation genuinely requires them.

Final art should support transparent backgrounds where practical, dialogue/battle-intro scaling, readable phone-size silhouettes, stable distinguishing features/faction markers, and no baked-in UI labels. Exact pixel dimensions are finalized with the renderer/UI pipeline.

Manifest fields: `character_id`, `display_name`, `role`, `dialogue_portrait_asset_id`, `battle_intro_portrait_asset_id`, `faction`, `story_usage`, `status`, `source_file`.
