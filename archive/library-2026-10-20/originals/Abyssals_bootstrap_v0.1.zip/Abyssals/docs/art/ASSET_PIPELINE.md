# Asset Pipeline

Gameplay references **stable asset IDs**, not arbitrary filenames. Missing production assets may use explicit placeholder status during development; they may not silently fall back to the wrong character/species.

Asset families: 187 Abyssal front sprites; human full-body portraits; generic trainer portraits; environment/background families; 18 Type-1 execution proxies; UI/VFX/audio.

Prefer lower-kebab-case physical filenames and stable IDs in data. Keep the mapping in manifests, not scattered through gameplay code.
