# Canon Conflict Register

## C-001 — Checklist 09 execution proxy count

**RESOLVED BY VERSION PRECEDENCE.** v1.0 said twelve; v1.1 says eighteen canonical Type-1 proxies; Checklist 16 delegates to v1.1. Implementation baseline: **18**.

## C-002 — Finale human restoration allocation

**GATED FOR FINALE IMPLEMENTATION.** Checklist 10 says five human restorations are elective and describes that as superseding Checklist 09 v1.0. Later Checklist 09 v1.1 again states that Pate and Trade consume two automatically, leaving three discretionary leader restorations.

This does not block Phase 0 or Phase 1. Before finale implementation, record one explicit project ruling and update this register rather than guessing.
