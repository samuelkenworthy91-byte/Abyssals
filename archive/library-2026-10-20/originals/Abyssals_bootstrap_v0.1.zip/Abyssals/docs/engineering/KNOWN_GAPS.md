# Known Gaps / Production Gates

## G-001 — Checklist 17 completed lock not located

The master reference defines Checklist 17 — Overworld Interaction Rules (tile/grid dimensions, movement, collision, warps, interaction, trainer line-of-sight, menus, NPC behaviour, map-state swapping). No completed locked Checklist 17 artifact has been located.

**Effect:** Phase 0/1 may proceed; production overworld/Phase 2 is gated.

## G-002 — Species-by-species encounter tables not populated

`ENCOUNTER_TABLE_REFERENCE_v1.1.md` explicitly says species-by-species tables remain to be populated.

**Effect:** schema/importer may be built; Codex/Claude must not invent production route tables. Phase 2 requires authored canonical tables.

## G-003 — Original source binaries not yet in Git

Copy verified originals into `docs/locked/source/` and `data/source/`. Do not recreate them from summaries.

## G-004 — 187 existing front sprites not yet in Git

The repository reserves canonical paths/manifests.

## G-005 — Human portraits pending

Full-body portraits for characters/trainers/leaders will be added later.

## G-006 — Environment art pending

Cities/routes/dungeons/interiors/battle backgrounds/Hell art are a separate workstream.

## G-007 — Final renderer/game engine intentionally open

TypeScript/Vite/Vitest are a reversible shell. Do not add a large rendering engine without an ADR/review.
