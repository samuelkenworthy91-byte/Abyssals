# Data Schema Specification

Status: **IMPLEMENTATION CONTRACT v0.1**

This defines schema boundaries, not replacement canon.

## Stable IDs

Display names may change; stable IDs do not. Save data stores IDs, not labels. Retired shipped IDs are never reused.

## Species

Minimum runtime fields: Dex ID (1..187), stable species ID, display name, Type 1/2, six base stats, BST, ability slots, evolution family/stage and front-sprite asset ID.

Hard validation: exactly 187 rows; unique IDs; six numeric stats; stat sum equals BST; legal canonical types; referenced abilities exist.

## Moves

Canonical identity/content comes from the 354-move catalogue plus Checklist 12 metadata. Runtime data includes stable move ID, name, type, PP, power/null, effect key/text, signature ownership, PHYSICAL/SPECIAL/STATUS category, accuracy, priority and target class.

Hard validation: 354 identities; no unknown learnset moves; signature-family restrictions; Checklist 12 category/accuracy/priority constraints.

## Learnsets

Each row binds species ID, learn level, move ID, acquisition and source-row provenance. Import diagnostics must identify the exact source row.

## Evolution

Each path has a stable path ID, source/target species, method (LEVEL/ITEM/STORY_CHOICE), trigger/minimum, optional item/story binding and signed promotion delta derived from canonical base stats. Canonical total: 98 paths = 75 level + 15 item + 8 story-choice.

## Abyssal instance

Persistent identity must support: instance ID, species, nickname, level/XP, immutable growth seed, rolled six stats, ability, four moves/PP, evolution history, training effects, held item, favourite flag, optional original starter owner and optional canonical `starter_lives_remaining` 0..3.

Only Aimon/Pate/Trade's three original starter individuals receive the special life state.

## Memorial record

Preserve exact original instance identity/state required by Checklist 07: species/form, nickname, level/XP, growth seed, exact stats, ability, current four moves, evolution history, active training, death location/chapter/order, sprite/form key and deterministic epitaph key.

## Party/reserve

Active party is ordered with maximum six. Reserve is dynamically sized. References must be unique/non-stale. Living reserve entry restores HP/PP and clears ordinary temporary status without altering progression/lives.

## Battle state

Explicitly persist/represent deterministic RNG, active combatants, pending action, KO batch, end-turn layer, active/native field, escape attempt count, capture outcome, pending starter return, outcome classification, progression queue and story handoff. Never infer mechanics from animation state.

## Story state

Checklist 10: saved fields use lower_snake_case; compact enum/state machines; historical facts remain queryable; convenience flags are derived; CHxx-Eyy/CHxx-Oyy IDs remain stable.

## Ironman save envelope

Checklist 15 concepts include campaign slot 1..3, monotonic commit sequence, schema/integrity version, current snapshot, two hidden recovery generations, journal/checkpoint, optional prepared transaction, battle RNG state, fixed encounter seed/payload, single-writer lease and run state/end reason.
