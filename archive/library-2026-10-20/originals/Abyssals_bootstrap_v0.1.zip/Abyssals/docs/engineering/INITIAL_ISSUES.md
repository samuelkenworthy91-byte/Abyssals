# Initial GitHub Issue / Milestone Backlog

## Production Bootstrap
- [ ] Import original locked sources with provenance
- [ ] Import 187 front-facing Abyssal sprites
- [ ] Close/import Checklist 17 lock
- [ ] Resolve finale human-restoration conflict before finale implementation
- [ ] Author/import production species encounter tables
- [ ] Approve/replace ADR-0001

## Phase 0
- [ ] Runtime schemas
- [ ] Species/stats/abilities importer
- [ ] Move catalogue importer
- [ ] Learnset importer + Checklist 12 validator
- [ ] Evolution importer + 98-path validator
- [ ] Deterministic versioned RNG
- [ ] Instance identity/growth replay
- [ ] Party/reserve invariants
- [ ] Death/memorial transaction
- [ ] Starter-life state machine
- [ ] Capture transaction
- [ ] Evolution transaction
- [ ] Ironman save primitives
- [ ] Phase 0 regression suite

## Phase 1
- [ ] Battle state-machine sandbox
- [ ] Action/KO batch ordering
- [ ] Switching/Set replacement
- [ ] Wild Run
- [ ] Surrender-Parley
- [ ] Capture
- [ ] Warden fields
- [ ] XP/progression/evolution handoff
- [ ] Checklist 16 minimum presentation
- [ ] Checklist 13/14/15 regression matrix
- [ ] Physical player-test gate

## Art Integration
- [ ] Named-character portraits
- [ ] Generic trainer portrait registry
- [ ] Battle-background registry
- [ ] 18 execution proxy assets
- [ ] Asset validation
