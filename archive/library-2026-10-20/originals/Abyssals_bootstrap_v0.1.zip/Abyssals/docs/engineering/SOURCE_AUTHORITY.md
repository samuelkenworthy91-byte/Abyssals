# Source Authority

Status: **ENGINEERING GOVERNANCE v0.1**

## Precedence

1. Latest explicit user-approved instruction/revision.
2. Latest version of the checklist owning the mechanic.
3. Later locked checklist explicitly superseding an earlier rule.
4. Locked Story Bible for narrative sequence/character causality.
5. Designated canonical workbook/reference for bulk authored data.
6. Engineering docs/ADRs.
7. Code/tests.

Higher explicit source versions win over older versions of the same authority unless stated otherwise.

### Known version precedence

`ABYSSALS_CHECKLIST_09_Leader_Trainer_Fate_System_LOCKED_v1.1.docx` supersedes v1.0. Use the v1.1 **eighteen Type-1 execution proxies**, not the obsolete v1.0 twelve-proxy wording. Checklist 16 explicitly points to Checklist 09 v1.1.

## Canonical terminology

New implementation/player-facing copy uses `Abyssal` / `Abyssals`. Legacy filenames remain unchanged for provenance.

## Ownership summary

- Checklist 01: deterministic stat growth.
- 02/03: encounter/world framework and connection graph.
- 04: trainers, teams, AI.
- 05: Hell Warden terrain.
- 06: items, economy, training effects.
- 07: memorial/resurrection.
- 08: active party/reserve.
- 09 v1.1: human leader fate/execution proxy system.
- 10: authoritative story/event state.
- 11: evolution.
- 12: learnsets/move metadata.
- 13: battle edge cases/order.
- 14: original-starter life system.
- 15: Ironman persistence.
- 16: battle presentation.
- 17: overworld interaction — completed locked artifact not yet located/imported.
