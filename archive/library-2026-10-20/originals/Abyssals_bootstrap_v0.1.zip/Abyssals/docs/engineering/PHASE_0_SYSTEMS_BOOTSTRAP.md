# Phase 0 — Systems Bootstrap

Status: **READY TO START**

## Goal

Prove locked rules can be represented deterministically before building the campaign.

## In scope

1. Source import/provenance pipeline.
2. Canonical schemas.
3. Versioned deterministic hashing/RNG state.
4. Species/ability/move/learnset/evolution compiled data.
5. Abyssal instance model.
6. 100-XP level progression.
7. Checklist 01 growth and historical simulation.
8. Party/reserve integrity.
9. Presentation-independent battle state skeleton.
10. Lethal 0-HP/death pipeline.
11. Original-starter life state.
12. Capture result/destination transaction.
13. Evolution transaction.
14. Checklist 15 persistence primitives: 3 slots; current + 2 hidden recovery generations; monotonic commit sequence; journal/transaction boundaries; battle/encounter determinism; single-writer abstraction.
15. Automated validation/tests.

## Out of scope

Story chapters, production overworld/maps, final renderer, finished battle presentation, environment art, human portraits, full shop/memorial UI, finale restoration allocator and unauthored encounter tables.

## Minimum tests

- deterministic growth replay and no reload/action-order reroll;
- higher-level historical growth simulation;
- signed evolution deltas;
- exact instance identity;
- party max six/no duplicate roster refs;
- reserve-heal transaction;
- starter 3→2→1 non-final handling and 1→0 permanent death;
- final-dead starter memorial restoration to one life;
- memorial exact-state preservation;
- atomic transaction failure rollback;
- RNG serialization reproduces next draw;
- unsupported future save schema rejection.

## Gate to Phase 1

Available canonical imports produce zero hard errors; deterministic/persistence tests pass; mechanics do not depend on UI ordering; missing content is reported rather than fabricated.
