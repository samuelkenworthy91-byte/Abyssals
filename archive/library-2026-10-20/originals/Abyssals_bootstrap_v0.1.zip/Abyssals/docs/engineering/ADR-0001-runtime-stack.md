# ADR-0001 — Runtime / Tooling Baseline

Status: **PROPOSED / REVERSIBLE**

Use TypeScript for deterministic domain logic/schemas, Vite for a lightweight browser shell, and Vitest for regression tests.

**No rendering/game engine is selected.** Do not add Phaser, Pixi, React, Vue, Godot-export infrastructure or another large runtime layer solely from familiarity. A later ADR should select rendering based on the locked overworld/battle requirements and device testing.
