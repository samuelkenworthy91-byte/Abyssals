# Phase 2 — Vertical Slice

Status: **GATED**

Proposed slice: Civeton → first outbound route/encounter space → meaningful trainer sequence → first town-service loop.

Prerequisites: Phase 0 pass; Phase 1 pass; completed Checklist 17 lock imported; production encounter tables for the slice; required species sprites; minimal navigable environment assets/placeholders. Human portraits may remain placeholders if stable IDs are wired.

This phase proves overworld movement/collision, map transitions, encounters, trainer interaction, dialogue/state, battle handoff/return, capture destination, healing/reserve boundaries, cross-context save/resume, mobile usability and asset-manifest integration.
