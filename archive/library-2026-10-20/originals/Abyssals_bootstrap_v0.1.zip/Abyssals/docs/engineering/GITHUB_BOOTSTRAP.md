# GitHub Bootstrap

Intended repository name: `Abyssals`.

Create it empty if possible. Recommended branch: `main`.

Suggested first commits:
1. `chore: initialize Abyssals production scaffold`
2. `docs: import locked source authorities`
3. `assets: import canonical Abyssal front sprites`
4. `build: begin Phase 0 data import and validation`
