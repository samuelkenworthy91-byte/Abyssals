# Repository Structure

```text
Abyssals/
├── IMPLEMENTATION_MASTER.md
├── AGENTS.md
├── CLAUDE.md
├── docs/{engineering,locked,art}/
├── data/{source,generated,schemas,manifests}/
├── src/{core,domain,battle,capture,progression,roster,save,story,overworld,ui}/
├── public/assets/{abyssals/front,portraits,backgrounds,vfx,audio}/
├── tests/
├── tools/{data-import,validation}/
└── .github/
```

Folder ownership is architectural, not permission to duplicate data. A species definition exists once in generated canonical data; other systems reference its stable ID.
