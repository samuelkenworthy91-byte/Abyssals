# First Codex / Claude Handoff Prompt

Read `IMPLEMENTATION_MASTER.md`, `SOURCE_AUTHORITY.md`, `KNOWN_GAPS.md`, `CANON_CONFLICT_REGISTER.md`, and `PHASE_0_SYSTEMS_BOOTSTRAP.md` before changes.

Implement **Phase 0 only**. Treat owning locked sources as authority. Do not redesign, rebalance, invent missing content, begin production overworld/story, or add a large rendering engine without a separate approved ADR. Build deterministic importers/validators rather than copying catalogue rows. Keep mechanics independent of UI. Persist sufficient RNG/transaction state to prevent reload rerolls. Add regression tests. Record gaps/conflicts instead of guessing. Update `CHANGELOG.md`.

Before completion run:

```text
npm run typecheck
npm test
npm run build
npm run validate
```

Return exact files changed, systems implemented, test/validation results, blocked items and their source. Do not claim later phases are complete.
