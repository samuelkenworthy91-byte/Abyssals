# Phase 1 — Battle Sandbox

Status: **PLANNED AFTER PHASE 0**

Build a storyless developer sandbox using canonical data and deterministic save state.

Exercise Fight, Abyssals/Set-style switching, Items, wild Run, trainer/leader Surrender-Parley, capture, permanent death, starter lives/end-round 10% return, multi-hit lethal handling, simultaneous KOs, mutual-final-KO reserve-sensitive victory, recoil/self/residual lethality, Warden fields/replacement/resumption, XP/progression/moves/evolution, and Ironman crash/resume cases.

Minimum Checklist 16 presentation: first-person player view; no player active Abyssal sprite; visible enemy front sprite; exact HP + bar; status; starter pips; field chip; mobile 2×2 command grid; capture closeness bar; effectiveness/critical text; placeholder trainer portrait support. No back-sprite dependency.

Acceptance uses Checklist 13/14/15 regression IDs plus physical player testing.
