# CLAUDE.md — Claude Code Contract

Treat `IMPLEMENTATION_MASTER.md` and `docs/engineering/SOURCE_AUTHORITY.md` as standing instructions.

Before a feature: locate the owning canonical source, inspect architecture/tests, keep the implementation boundary narrow, implement without altering canon, run validation/tests, and update changelog/gap registers.

Do not expand a phase into later story/world scope. Do not improvise around contradictory or missing canon. All deterministic decisions must be reproducible from persisted state; presentation consumes mechanical state and never creates it.
