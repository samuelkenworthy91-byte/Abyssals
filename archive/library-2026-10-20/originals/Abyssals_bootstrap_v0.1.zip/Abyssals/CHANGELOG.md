# Changelog

## [Unreleased]

### Added
- Production repository scaffold.
- Engineering authority and agent contracts.
- Phase 0/1/2 gate specifications.
- Source/data import architecture.
- Character/Abyssal/execution asset manifests.
- GitHub CI/templates.
- Known-gap and canon-conflict registers.

### Not yet imported
- Original locked source files.
- Existing 187 front-facing Abyssal sprites.
- Human portraits.
- Environment art.
