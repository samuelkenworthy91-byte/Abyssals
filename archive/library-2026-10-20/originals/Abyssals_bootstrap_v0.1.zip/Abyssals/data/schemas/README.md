# Runtime Data Schemas

Phase 0 implements machine-validated schemas for species, abilities, moves, learnsets, evolution paths, items, trainers, encounter tables, story state and asset manifests. Schema files must not duplicate canonical catalogue content.
