import fs from "node:fs";
import path from "node:path";
const p=path.resolve("docs/locked/SOURCE_MANIFEST.json");
const m=JSON.parse(fs.readFileSync(p,"utf8"));
if(m.manifest_version!==1) throw new Error(`Unsupported source manifest version: ${m.manifest_version}`);
if(!Array.isArray(m.locked_documents)||!m.locked_documents.length) throw new Error("Source manifest must list locked documents.");
if(!Array.isArray(m.canonical_data_workbooks)||!m.canonical_data_workbooks.length) throw new Error("Source manifest must list canonical data workbooks.");
console.log(`Source manifest valid: ${m.locked_documents.length} locked/reference docs, ${m.canonical_data_workbooks.length} canonical data workbooks.`);
if(m.missing_or_gated?.length){console.log("Known gated sources:");for(const x of m.missing_or_gated) console.log(`- ${x}`)}
