# Data Importers

Phase 0 importers must retain exact source provenance, deterministic output ordering and row-level diagnostics; reject unknown IDs rather than silently coercing them; write generated artifacts to `data/generated/`; and fail hard on canonical-count/integrity errors.
