# Core

Phase 0 adds presentation-independent stable hashing/seed derivation, versioned RNG state, IDs, deterministic math/rounding helpers and transaction identifiers. Do not put authored species/move tables here.
