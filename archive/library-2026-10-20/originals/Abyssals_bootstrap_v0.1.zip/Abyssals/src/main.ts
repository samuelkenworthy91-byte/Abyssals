const app = document.querySelector<HTMLElement>("#app");
if (!app) throw new Error("Missing #app root.");
app.innerHTML = `<section><h1>Abyssals</h1><p>Engineering bootstrap. Gameplay implementation begins in Phase 0.</p></section>`;
