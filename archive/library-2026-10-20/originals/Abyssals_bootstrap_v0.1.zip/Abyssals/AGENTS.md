# AGENTS.md — Codex / Coding Agent Contract

Read `IMPLEMENTATION_MASTER.md` before modifying code.

- Inspect existing files/tests first.
- Identify the owning locked source before implementing a rule.
- Work only within the requested phase/task.
- Prefer small reviewable changes.
- Do not redesign, rebalance or invent missing content.
- Do not delete source provenance.
- Build importers instead of hard-coding catalogue rows.
- Never create a hidden morality score.
- Never make committed RNG outcomes rerollable by reload.
- Never create a mandatory back-sprite pipeline.

If sources conflict, check `SOURCE_AUTHORITY.md` and `CANON_CONFLICT_REGISTER.md`; if unresolved, gate only the affected feature and continue unrelated work.

Before declaring completion run:

```bash
npm run typecheck
npm test
npm run build
npm run validate
```

Main must remain buildable. Schema/migration changes require tests. Canon-source changes require manifest/changelog updates.
