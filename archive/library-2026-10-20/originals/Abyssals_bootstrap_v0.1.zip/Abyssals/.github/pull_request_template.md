## Scope
What narrow phase/task does this PR implement?

## Canon authority
List the owning locked source(s).

## Changes
-

## Validation
- [ ] `npm run typecheck`
- [ ] `npm test`
- [ ] `npm run validate`
- [ ] `npm run build`

## Canon safety
- [ ] No locked mechanic silently changed
- [ ] No missing content invented
- [ ] Conflicts/gaps recorded
- [ ] Save/schema changes considered for migration/integrity
